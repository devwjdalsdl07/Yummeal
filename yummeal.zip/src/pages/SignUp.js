import React from "react";
import {
  JoinArea,
  JoinBtn,
  JoinContainer,
  JoinFormGroup,
  JoinId,
  JoinPw,
  JoinPwConfirm,
  JoinText,
  JoinTitleWrapTop,
  JoinWrap,
} from "../style/SignUpCss";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircle } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router";
import { DownOutlined } from "@ant-design/icons";
import { Button, Space, Dropdown } from "antd";

const SignUp = () => {
  const navigate = useNavigate();
  const handleSignUp = () => {
    navigate("/Login");
  };
  const handleButtonClick = e => {
    // message.info("Click on left button.");
    console.log("click left button", e);
  };
  const handleMenuClick = e => {
    // message.info("Click on menu item.");
    console.log("click", e);
    console.log(e);
  };
  const items = [
    {
      label: "1st menu item",
      key: "1",
    },
    {
      label: "1st menu item",
      key: "2",
    },
    {
      label: "1st menu item",
      key: "3",
    },
    {
      label: "1st menu item",
      key: "4",
    },
    {
      label: "1st menu item",
      key: "5",
    },
    {
      label: "1st menu item",
      key: "5",
    },
    {
      label: "1st menu item",
      key: "5",
    },
    {
      label: "1st menu item",
      key: "5",
    },
    {
      label: "1st menu item",
      key: "5",
    },
    {
      label: "1st menu item",
      key: "5",
    },
    {
      label: "1st menu item",
      key: "5",
    },
    {
      label: "1st menu item",
      key: "5",
    },
    {
      label: "1st menu item",
      key: "5",
    },
    {
      label: "1st menu item",
      key: "5",
    },
    {
      label: "1st menu item",
      key: "5",
    },
  ];
  const menuProps = {
    items,
    onClick: handleMenuClick,
  };

  return (
    <JoinContainer>
      <JoinArea>
        <JoinText>회원가입</JoinText>
        <JoinWrap>
          <JoinTitleWrapTop>
            <h3>정보입력</h3>
            <div>
              <i>
                <FontAwesomeIcon icon={faCircle} />
              </i>
              <span>는 필수입력사항 입니다.</span>
            </div>
          </JoinTitleWrapTop>
          <JoinFormGroup>
            <JoinId>
              <span>
                <i>
                  <FontAwesomeIcon icon={faCircle} />
                </i>
                아이디
              </span>
              <input
                type="text"
                placeholder="아이디를 입력하세요"
                maxLength={100}
              />
            </JoinId>
            <JoinPw>
              <span>
                <i>
                  <FontAwesomeIcon icon={faCircle} />
                </i>
                비밀번호
              </span>
              <input
                type="text"
                placeholder="비밀번호를 입력하세요"
                maxLength={100}
              />
            </JoinPw>
            <JoinPwConfirm>
              <span>
                <i>
                  <FontAwesomeIcon icon={faCircle} />
                </i>
                비밀번호 확인
              </span>
              <input
                type="text"
                placeholder="비밀번호를 한번 더 입력하세요"
                maxLength={100}
              />
            </JoinPwConfirm>
            <div className="pw-group">
              <span>
                <i>
                  <FontAwesomeIcon icon={faCircle} />
                </i>
                이름
              </span>
              <input
                type="text"
                placeholder="이름을 입력하세요"
                maxLength={100}
              />
            </div>
            <div>
              <span>
                <i>
                  <FontAwesomeIcon icon={faCircle} />
                </i>
                휴대전화
              </span>
              <input
                type="text"
                placeholder="전화번호를 입력하세요"
                maxLength={100}
              />
            </div>
            <div>
              <span>
                <i>
                  <FontAwesomeIcon icon={faCircle} />
                </i>
                이메일
              </span>
              <input
                type="text"
                placeholder="이메일을 입력하세요"
                maxLength={100}
              />
            </div>
            {/* 생년월일 드랍박스 들어갈 자리 */}
            <div>
              <span>
                <i>
                  <FontAwesomeIcon icon={faCircle} />
                </i>
                아이 생년월일
              </span>
              <spaceWrap>
                <Dropdown menu={menuProps} trigger={["click"]}>
                  <Button>
                    <Space>
                      년도 선택
                      <DownOutlined />
                    </Space>
                  </Button>
                </Dropdown>
                <Dropdown menu={menuProps} trigger={["click"]}>
                  <Button>
                    <Space>
                      월 선택
                      <DownOutlined />
                    </Space>
                  </Button>
                </Dropdown>
                <Dropdown menu={menuProps} trigger={["click"]}>
                  <Button>
                    <Space>
                      일 선택
                      <DownOutlined />
                    </Space>
                  </Button>
                </Dropdown>
              </spaceWrap>
              {/* <input
                type="text"
                placeholder="이메일을 입력하세요"
                maxLength={100}
              /> */}
            </div>
          </JoinFormGroup>
          <JoinBtn onClick={handleSignUp}>회원가입</JoinBtn>
        </JoinWrap>
      </JoinArea>
    </JoinContainer>
  );
};

export default SignUp;
