import React from 'react'

const AdminMain = () => {
  return (
    <div>AdminMain</div>
  )
}

export default AdminMain