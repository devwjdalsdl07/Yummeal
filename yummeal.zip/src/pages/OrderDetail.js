import React from 'react'

const OrderDetail = () => {
  return (
    <div>OrderDetail</div>
  )
}

export default OrderDetail