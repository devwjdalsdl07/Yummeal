import React from 'react'

const ShopCart = () => {
  return (
    <div>ShopCart</div>
  )
}

export default ShopCart