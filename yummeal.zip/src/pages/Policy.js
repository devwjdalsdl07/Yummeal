import React from 'react'

const Policy = () => {
  return (
    <div>Policy</div>
  )
}

export default Policy