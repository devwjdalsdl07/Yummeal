import React from "react";

const UseGuide = () => {
  return <div>UseGuide</div>;
};

export default UseGuide;
