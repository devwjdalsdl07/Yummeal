import React from 'react'

const AdminAddItem = () => {
  return (
    <div>AdminAddItem</div>
  )
}

export default AdminAddItem