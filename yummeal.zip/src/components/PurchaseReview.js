import React from "react";

const PurchaseReview = () => {
//     const handlePurchaseReview = () => {
    
//     }
  return (
    
    <div className="order-prodbtn">
        <button style={{padding:"8px"}}>리뷰 작성</button>
           {/* {showModal === true ? (
        <CartItemModal
          setShowModal={setShowModal}
          handleCartShow={handleCartShow}
        />
      ) : null} */}
    </div>
  );
};

export default PurchaseReview;
