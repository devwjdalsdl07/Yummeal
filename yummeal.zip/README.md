# 2차 협업 프로젝트 이유식 밀키트 쇼핑몰

### 2차 팀명

## 프로젝트 정보

- [Notion](https://)
- [Figma(wireframe)](https://)
- [Figma(flowchart)](https://)

## 활용 모듈

<!-- - <img src="https://img.shields.io/badge/React-263238?style=flat&logo=React&logoColor=skyblue"> -->

## 프로젝트 기간

- 2023.07.14 ~ 2023.08.18

## 팀원 소개 및 역할

- Frontend
  - 팀장 : 손용수(장바구니페이지, 결제페이지, 결제내역페이지 )
  - 팀원 : 박지성(관리자 메인페이지, 관리자 상품등록페이지)<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;손정민(회원가입페이지, 로그인페이지, 마이페이지)<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;정다혜(메인페이지, 검색페이지, 상세정보페이지)
- Backend
  - 팀장 : 이진규
  - 팀원 : 권민구, 김다율, 서영기, 홍기윤

## 주요기능

####
